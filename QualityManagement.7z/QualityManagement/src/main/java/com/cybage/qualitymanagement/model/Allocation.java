package com.cybage.qualitymanagement.model;

import java.io.Serializable;
import javax.persistence.*;



@Entity
@Table(name="allocation_table")
@NamedQuery(name="Allocation.findAll", query="SELECT r FROM Allocation r")
public class Allocation  {
	private static final long serialVersionUID = 1L;
	private int allocationId;
	private int status;
	private String reason;
	private Employee employee;
	private Project projectTable;

	public Allocation() {
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getAllocationId() {
		return allocationId;
	}


	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}


	public int getStatus() {
		return status;
	}


	public void setStatus(int status) {
		this.status = status;
	}


	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}

	
	//bi-directional many-to-one association to Employee
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Empid")
	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	//bi-directional many-to-one association to Project
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="Proj_id")
	public Project getProjectTable() {
		return this.projectTable;
	}

	public void setProjectTable(Project projectTable) {
		this.projectTable = projectTable;
	}

	@Override
	public String toString() {
		return "Allocation [allocationId=" + allocationId + ", status=" + status + ", reason=" + reason + ", employee="
				+ employee + ", projectTable=" + projectTable + "]";
	}


	

	
}