package com.cybage.qualitymanagement.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cybage.qualitymanagement.dao.TestPlanDao;
import com.cybage.qualitymanagement.model.Allocation;
import com.cybage.qualitymanagement.model.Employee;
import com.cybage.qualitymanagement.model.Project;
import com.cybage.qualitymanagement.model.ResourceProjectTable;
import com.cybage.qualitymanagement.model.RoleTable;
import com.cybage.qualitymanagement.model.TestPlanModel;


@Repository
public class TestPlanDaoImpl implements TestPlanDao {

	@Autowired
	SessionFactory sf;

	@Autowired
	HibernateTemplate hibernateTemplate;

	public TestPlanDaoImpl() {
		System.out.println("in dao impl");
	}

	@Override
	public TestPlanModel addTestPlan(TestPlanModel testPlanModel){
		System.out.println("addTestPlan() Dao");
		Session session=sf.getCurrentSession();
		session.save(testPlanModel);
		System.out.println("get role list");
		
		Employee emp=(Employee)session.get(Employee.class, 1);
		System.out.println(emp);
		String projectName="ResourceManagement2";
		
		Project newProject=(Project)session.createQuery
				("from Project p where p.proj_name=:projName")
				.setParameter("projName", projectName)
				.uniqueResult();
		
		List<ResourceProjectTable> resProjs=emp.getResourceProjectTables();
		List<RoleTable> roles=emp.getRoleTables();
		System.out.println("resProjects"+resProjs);
		
		for (ResourceProjectTable resourceProjectTable : resProjs) {
			Project oldProject=resourceProjectTable.getProjectTable();
			System.out.println("Before update Old Project"+oldProject);
			if(oldProject.getProj_name().equals("ResourcePool"))
			{
				System.out.println("inn if");
				resourceProjectTable.setProjectTable(newProject);
				resourceProjectTable.setStart_date(new Date());
				resourceProjectTable.setEnd_date(new Date());
				resourceProjectTable.setBilling(99.99F);
				System.out.println("Old Project after update"+oldProject);
				break;
			}
		}
		
		for (RoleTable roleTable : roles) {
			Project oldProject=roleTable.getProjectTable();
			System.out.println("Old projects List "+oldProject);
			if(oldProject.getProj_name().equalsIgnoreCase("ResourcePool"))
			{	
				roleTable.setRole("QA");
				roleTable.setProjectTable(newProject);
				break;
			}
		}
		
		System.out.println("Line Before Dao returns");
		
		return testPlanModel;
	}


	@Override
	public TestPlanModel getTestPlan() {
		/*
		 * @SuppressWarnings("unchecked") ArrayList<String>
		 * c=(ArrayList<String>) sf.getCurrentSession() .createQuery(
		 * "select c.testPlanTitle from TestPlan c") .list(); return c;
		 */
		TestPlanModel testPlanModel = (TestPlanModel) hibernateTemplate.get(TestPlanModel.class, 1);
		return testPlanModel;
	}

	@Override
	public TestPlanModel getTestPlanByTitle(String planTitle) {
		TestPlanModel testPlanModel = (TestPlanModel) sf.getCurrentSession()
				.createQuery("select c from TestPlanModel c where c.testPlanTitle = :title")
				.setParameter("title", planTitle)
				.uniqueResult();

		return testPlanModel;
	}
}
