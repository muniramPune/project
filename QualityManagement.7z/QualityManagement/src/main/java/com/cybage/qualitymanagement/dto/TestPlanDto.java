/*package com.cybage.qualitymanagement.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TestPlans")
public class TestPlanDto implements Serializable {
	
	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 1L;
	Integer testplan_id;
	String title;
	String description;
	String status;
	
	
	public TestPlanDto() {
		System.out.println("in testplan  constr");
	}


	public TestPlanDto(String title, String description, String status) {
		super();
		this.title = title;
		this.description = description;
		this.status = status;
	}

	

	@Override
	public String toString() {
		return "TestPlan [testplan_id=" + testplan_id + ", title=" + title + ", description=" + description
				+ ", status=" + status + "]";
	}


	@Id
	@GeneratedValue
	public Integer getTestplan_id() {
		return testplan_id;
	}


	public void setTestplan_id(Integer testplan_id) {
		this.testplan_id = testplan_id;
	}

	
	@Column(name="title")
	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name="description")
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	@Column(name="status")
	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	

}
*/