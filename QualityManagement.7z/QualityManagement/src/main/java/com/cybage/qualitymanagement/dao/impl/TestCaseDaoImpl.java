package com.cybage.qualitymanagement.dao.impl;

import java.util.ArrayList;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.qualitymanagement.dao.TestCaseDao;
import com.cybage.qualitymanagement.model.TestCaseModel;
import com.cybage.qualitymanagement.model.TestPlanModel;
import com.cybage.qualitymanagement.service.TestPlanService;

@Repository
public class TestCaseDaoImpl implements TestCaseDao{

	@Autowired
	SessionFactory sf;

	@Autowired
	HibernateTemplate hibernateTemplate;
	


	@SuppressWarnings("unchecked")
	public ArrayList<String> getTestPlanTitles() {
		
		ArrayList<String> c = (ArrayList<String>) sf.getCurrentSession()
				.createQuery("select c.testPlanTitle from TestPlanModel c").list();
		return c;

	}

	@Override
	public TestCaseModel addTestCase(TestCaseModel testCaseModel,TestPlanModel testPlanModel) {
		System.out.println("in Test CAse dao");	
		if(testPlanModel!=null && testPlanModel.addTestcaseModel(testCaseModel))
		{
			System.out.println(testPlanModel+"asdasd"+testCaseModel);
			return testCaseModel;
		}
		
		return null;

	}

}
